﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    public partial class Main : Form
    {
        private LiveAuthorEntities _db;
        private City _city;
        private Author _author_delete_update;
        public Main()
        {
            InitializeComponent();
            _db = new LiveAuthorEntities();
        }

        private void CountryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CountryForm country = new CountryForm();
            country.ShowDialog();
        }

        private void CityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CityForm city = new CityForm();
            city.ShowDialog();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            cmbCountry.DataSource = _db.Countries.Select(ct => new CMB_class { Id = ct.Id, Name = ct.CountryName }).ToList();
            cmbCity.DataSource = _db.Cities.Select(ct => new CMB_class { Id = ct.Id, Name = ct.CityName }).ToList();
            FIllDGV();
            BtnVisible(true);
        }

        private void CmbCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            int cityID = (cmbCity.SelectedItem as CMB_class).Id;
            _city = _db.Cities.Find(cityID);
            cmbCountry.Text = _city.Country.CountryName;
        }

        private async void BtnCreateAuthor_Click(object sender, EventArgs e)
        {
            if (this.CheckInput())
            {
                Author author = new Author();
                author.AuthorName = txbAuthorName.Text.Trim();
                author.AuthorSurname = txbAuthorSurname.Text.Trim();
                author.Phone = txbAuthorPhone.Text.Trim();

                if (txbAuthorAge.Text.IsNumber())
                {
                    author.Age =int.Parse(txbAuthorAge.Text.Trim());
                }
                else
                {
                    MessageBox.Show("Please enter the number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (txbAuthorEmail.Text.IsEmail())
                {
                    author.Email = txbAuthorEmail.Text.Trim();
                }
                else
                {
                    MessageBox.Show("Please enter correct email", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                author.CityID = (cmbCity.SelectedItem as CMB_class).Id;
                

                _db.Authors.Add(author);
                await _db.SaveChangesAsync();
                dgvListAuthor.DataSource = null;
                FIllDGV();
                RefreshTexBox();

            }
            else
            {
                MessageBox.Show("Please fill the inputs", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void FIllDGV()
        {

            dgvListAuthor.DataSource = _db.Authors.Select(at => new
            {

                at.Id,
                at.AuthorName,
                at.AuthorSurname,
                at.Age,
                at.Email,
                at.Phone,
                at.City.CityName,
                at.City.CountPeopleCity,
                at.City.Country.CountryName
            }).ToList();
        }

        private void RefreshTexBox()
        {
            txbAuthorName.Text = null;
            txbAuthorSurname.Text = null;
            txbAuthorEmail.Text = null;
            txbAuthorPhone.Text = null;
            txbAuthorAge.Text = null;
        }

        private void DgvListAuthor_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int dgvId =(int)dgvListAuthor.Rows[e.RowIndex].Cells[0].Value;
            _author_delete_update = _db.Authors.Find(dgvId);
            txbAuthorName.Text = _author_delete_update.AuthorName;
            txbAuthorSurname.Text = _author_delete_update.AuthorSurname;
            txbAuthorAge.Text = _author_delete_update.Age.ToString();
            txbAuthorEmail.Text = _author_delete_update.Email;
            txbAuthorPhone.Text = _author_delete_update.Phone;
            cmbCity.Text = _author_delete_update.City.CityName;
            cmbCountry.Text = _author_delete_update.City.Country.CountryName;

            BtnVisible(true);


        }

        private async void BtnUpdateAuthor_Click(object sender, EventArgs e)
        {
            if (this.CheckInput())
            {
                _author_delete_update.AuthorName = txbAuthorName.Text.Trim();
                _author_delete_update.AuthorSurname = txbAuthorSurname.Text.Trim();
                if (txbAuthorAge.Text.IsNumber())
                {
                    _author_delete_update.Age =int.Parse(txbAuthorAge.Text.Trim());
                }
                else
                {
                    MessageBox.Show("Please enter the number", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (txbAuthorEmail.Text.IsEmail())
                {
                    _author_delete_update.Email = txbAuthorEmail.Text.Trim();
                }
                else
                {
                    MessageBox.Show("Please enter correct Email", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                _author_delete_update.Phone = txbAuthorPhone.Text.Trim();
                _author_delete_update.City.CityName = cmbCity.Text;
                _author_delete_update.City.Country.CountryName = cmbCountry.Text;
                await _db.SaveChangesAsync();
                dgvListAuthor.DataSource = null;
                FIllDGV();

                RefreshTexBox();

            }
            else
            {
                MessageBox.Show("Please fill the inputs", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private async void BtnDeleteAuthor_Click(object sender, EventArgs e)
        {
            if (this.CheckInput())
            {
                _db.Authors.Remove(_author_delete_update);
                await _db.SaveChangesAsync();
                dgvListAuthor.DataSource = null;
                FIllDGV();
                RefreshTexBox();
            }
            else
            {
                MessageBox.Show("Please fill the inputs", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void CreateAuthorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnVisible(false);
        }

        public void BtnVisible(bool a)
        {
            if (a)
            {
                btnCreateAuthor.Visible = false;
                btnDeleteAuthor.Visible = true;
                btnUpdateAuthor.Visible = true;
            }
            else
            {
                btnCreateAuthor.Visible = true;
                btnDeleteAuthor.Visible = false;
                btnUpdateAuthor.Visible = false;

            }
        }
    }
}
