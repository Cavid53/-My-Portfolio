﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    public partial class CityForm : Form
    {
        private LiveAuthorEntities _db;
        private City _city_update_delete;
        public CityForm()
        {
            InitializeComponent();
            _db = new LiveAuthorEntities();
        }

        private void City_Load(object sender, EventArgs e)
        {
            cmbCountryCityForm.DataSource = _db.Countries.Select(ct => new CMB_class { Id = ct.Id, Name = ct.CountryName }).ToList();
            RefreshCMB();
            BtnVisible(true);

        }

        private  async void BtnCreateCity_Click(object sender, EventArgs e)
        {
            if (txbCityAdd.Text == "" || txbCountPeople.Text=="")
            {
                MessageBox.Show("Input is empty", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                City city = new City();
                city.CityName = txbCityAdd.Text.Trim();
                city.CountryID = (cmbCountryCityForm.SelectedItem as CMB_class).Id;
                
                if (txbCountPeople.Text.IsNumber())
                {
                    city.CountPeopleCity = int.Parse(txbCountPeople.Text.Trim());
                }
                else
                {
                    MessageBox.Show("Please correct enter people count.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                _db.Cities.Add(city);
                await _db.SaveChangesAsync();
                RefreshCMB();
                txbCityAdd.Text = null;
                txbCountPeople.Text = null;

            }
        }
        public void RefreshCMB()
        {
            cmbCityForm.DataSource = _db.Cities.Select(ct => new CMB_class { Id = ct.Id, Name = ct.CityName }).ToList();
        }

        private void CmbCityForm_SelectedValueChanged(object sender, EventArgs e)
        {
            int cmbID = (cmbCityForm.SelectedItem as CMB_class).Id;
            _city_update_delete = _db.Cities.Find(cmbID);
            txbCityAdd.Text = _city_update_delete.CityName;
            txbCountPeople.Text = _city_update_delete.CountPeopleCity.ToString();
            cmbCountryCityForm.Text = _city_update_delete.Country.CountryName;

            BtnVisible(true);

        }

        private async void BtnUpdateCity_Click(object sender, EventArgs e)
        {
            if (txbCityAdd.Text == "" || txbCountPeople.Text == "" ||cmbCountryCityForm.Text=="")
            {
                MessageBox.Show("Input is empty", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
               
                if (txbCountPeople.Text.IsNumber())
                {
                    _city_update_delete.CountPeopleCity =int.Parse(txbCountPeople.Text.Trim());
                }
                else
                {
                    MessageBox.Show("Please correct enter people count.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                _city_update_delete.CityName = txbCityAdd.Text.Trim();
                _city_update_delete.Country.CountryName = cmbCountryCityForm.Text.Trim();
                await _db.SaveChangesAsync();
                RefreshCMB();
                txbCityAdd.Text = null;
                txbCountPeople.Text = null;

            }
        }

        private void CreateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnVisible(false);
        }

        public void BtnVisible(bool a)
        {
            if (a)
            {
                btnCreateCity.Visible = false;
                btnDeleteCity.Visible = true;
                btnUpdateCity.Visible = true;
            }
            else
            {
                btnCreateCity.Visible = true;
                btnDeleteCity.Visible = false;
                btnUpdateCity.Visible = false;

            }
        }

        private async void BtnDeleteCity_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show($"Are you want {_city_update_delete.CityName} ?", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                _db.Cities.Remove(_city_update_delete);
                await _db.SaveChangesAsync();
                txbCityAdd.Text = null;
                txbCountPeople.Text = null;
                RefreshCMB();
                MessageBox.Show("Succesfully deleted", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
