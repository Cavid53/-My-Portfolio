﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    public partial class CountryForm : Form
    {

        private LiveAuthorEntities _db;
        private Country _country_update_delete;



        public CountryForm()
        {
            InitializeComponent();
            _db = new LiveAuthorEntities();
        }

        private async void BtnCreateCountry_Click(object sender, EventArgs e)
        {
            if (txbCountryAdd.Text == "")
            {
                MessageBox.Show("Input is empty", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                Country country = new Country();
                country.CountryName = txbCountryAdd.Text;
                _db.Countries.Add(country);
                await _db.SaveChangesAsync();
                RefreshCMB();
                txbCountryAdd.Text = null;
                BtnVisible(false);

            }
        }
        public void RefreshCMB()
        {
            cmbCountryForm.DataSource = _db.Countries.Select(ct => new CMB_class { Id = ct.Id, Name = ct.CountryName }).ToList();
        }

        private void CountryForm_Load(object sender, EventArgs e)
        {
            RefreshCMB();
            txbCountryAdd.Text = null;
          
        }
        private async void CmbCountryForm_SelectedValueChanged(object sender, EventArgs e)
        {

            int CmbId = (cmbCountryForm.SelectedItem as CMB_class).Id;
            _country_update_delete = _db.Countries.Find(CmbId);
            txbCountryAdd.Text = _country_update_delete.CountryName;
            BtnVisible(true);


        }

        private async void BtnUpdateCountry_Click(object sender, EventArgs e)
        {

            if (txbCountryAdd.Text == "" || cmbCountryForm.Text=="")
            {
                MessageBox.Show("Input is empty", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                _country_update_delete.CountryName = txbCountryAdd.Text;
                await _db.SaveChangesAsync();
                RefreshCMB();
                txbCountryAdd.Text = null;
            }
            
        }

        public void BtnVisible(bool a)
        {
            if (a)
            {
                btnCreateCountry.Visible = false;
                btnDeleteCountry.Visible = true;
                btnUpdateCountry.Visible = true;
            }
            else
            {
                btnCreateCountry.Visible = true;
                btnDeleteCountry.Visible = false;
                btnUpdateCountry.Visible = false;

            }
        }

        private void CreateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnVisible(false);
        }

        private async void BtnDeleteCountry_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show($"Are you want deleted {_country_update_delete.CountryName} ?", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                var listC = _country_update_delete.Cities.ToList();
                foreach (var city in listC)
                {
                    var listA = city.Authors;
                    _db.Authors.RemoveRange(listA);
                    _db.SaveChanges();

                    _db.Cities.Remove(city);
                    _db.SaveChanges();
                }

                _db.Countries.Remove(_country_update_delete);
                await _db.SaveChangesAsync();
                txbCountryAdd.Text = null;
                RefreshCMB();
                MessageBox.Show("Succesfully deleted", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
